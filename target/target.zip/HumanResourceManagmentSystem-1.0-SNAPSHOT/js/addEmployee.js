function openForm() {
    document.getElementById("myForm").style.display = "block";

}
function NextForm() {
    document.getElementById("myForm").style.display = "none";
    document.getElementById("myForm2").style.display = "block";

}
function closeForm() {
    document.getElementById("myForm2").style.display = "none";
}
